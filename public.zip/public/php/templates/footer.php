<?php
$footer = '
    <div class="footer_links">
          <div class="footer_link"><a href="https://github.com/NYKOPRO/PHP-Project/tree/master" target="_blank">Code source</a></div>
    </div>
    <div class="footer_medias">
          <div class="footer_media"><a href="mailto:marius.munteanu18@gyb.ch">Munteanu Marius</a></div>
          <div class="footer_media"><a href="mailto:nicolas.jaton20@gyb.ch">Jaton Nicolas</a></div>
    </div>';
