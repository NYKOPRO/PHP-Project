<?php
$header = '
    <div class="title"> 
        <div class="header_title_primary"><a class="header_title_link" href="../index.php">Page d\'accueil</a></div>
    </div>
    <div class="header_titles">         
        <div class="header_title"><a class="header_title_link" href="addition.php">Addition</a></div>
        <div class="header_title"><a class="header_title_link" href="soustraction.php">Soustraction</a></div>
        <div class="header_title"><a class="header_title_link" href="multiplication.php">Multiplication</a></div>
        <div class="header_title"><a class="header_title_link" href="division.php">Division</a></div>
        <div class="header_title"><a class="header_title_link" href="mixte.php">Mixte</a></div>
    </div>';

$header_index = '
    <div class="title"> 
        <div class="header_title_primary"><a class="header_title_link" href="index.php">Page d\'accueil</a></div>
    </div>
    <div class="header_titles">         
        <div class="header_title"><a class="header_title_link" href="php/addition.php">Addition</a></div>
        <div class="header_title"><a class="header_title_link" href="php/soustraction.php">Soustraction</a></div>
        <div class="header_title"><a class="header_title_link" href="php/multiplication.php">Multiplication</a></div>
        <div class="header_title"><a class="header_title_link" href="php/division.php">Division</a></div>
        <div class="header_title"><a class="header_title_link" href="php/mixte.php">Mixte</a></div>
    </div>';
